const express = require('express');
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');
const XLSX = require('xlsx');

const app = express()

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'tradefile'
});

app.use(express.json());

const SECRET = 'secretkey';

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  connection.query(
    `SELECT * FROM users WHERE username = '${username}'`,
    (error, results) => {
      if (error) {
        return res.status(500).json({ message: error.message });
      }

      if (!results.length) {
        return res.status(400).json({ message: 'User not found' });
      }

      const user = results[0];

      if (user.password !== password) {
        return res.status(400).json({ message: 'Incorrect password' });
      }

      const token = jwt.sign({ id: user.id, username: user.type}, SECRET);
      const val = results[0]['type'];

      res.json([{type:user.type,token:token}]);
    }
  );
});


const verifyToken = (req, res, next) => {
  const token = req.headers.authorization;

  if (!token) {
    return res.status(401).json({ message: 'Token is required' });
  }

  try {
    const decoded = jwt.verify(token, SECRET

    );

    req.user = decoded;

    next();

  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};


// app.get('/user/:val', verifyToken, (req, res) => {
//   if (req.params.val == 'admin') {
//     connection.query(
//       `SELECT * FROM user_data WHERE admin_id = ${req.user.id}`,
//       (error, results) => {
//         if (error) {
//           return res.status(500).json({ message: error.message });
//         }
//         res.send(results);
//       });
//   } else {
//     const query = `SELECT * FROM user_data WHERE ClientID = ?`;
//     const values = [req.params.val];

//     connection.query(
//       query, values,
//       (error, results) => {
//         if (error) {
//           return res.status(500).json({ message: error.message });
//         }
//         res.send(results);
//       });
//   }
// });



app.post('/register', (req, res) => {
  const { username, password, type } = req.body;

  connection.query(
    `SELECT * FROM users WHERE username = '${username}'`,
    (error, results) => {
      if (error) {
        return res.status(500).json({ message: error.message });
      }

      if (results.length) {
        return res.status(400).json({ message: 'Username already taken' });
      }

      connection.query(
        `INSERT INTO users (username, password ,type) VALUES ('${username}', '${password}','${type}')`,
        (error) => {
          if (error) {
            return res.status(500).json({ message: error.message });
          }

          res.json({ message: 'Registration successful' });
        }
      );
    }
  );
});



// const result = [];
// const map = new Map();

//     for (const item of data) {
//         if (!map.has(item.SecurityName)) {
//           map.set(item.SecurityName, 0);
//         }
//         map.set(item.SecurityName,item['BuySell'] == '1'? map.get(item.SecurityName) + item.Qty:map.get(item.SecurityName) - item.Qty);
//       }

//       for (const [SecurityName, Qty] of map) {
//         result.push({ SecurityName, Qty });
//       }


//     for (const item of data) {
//         if (!map.has(item.SecurityName)) {
//           map.set(item.SecurityName, 0);
//         }
//         map.set(item.SecurityName, map.get(item.SecurityName) - item.Qty);
//       }

//       for (const [SecurityName, Qty] of map) {
//         result.push({ SecurityName, Qty });
//       }

//       for (const item of data) {
//     }















const newData = [];
const expencs = [];

// const data = [
//   { name: 'John', age: 25 },
//   { name: 'Jane', age: 30 },
//   { name: 'Jim', age: 35 }
// ];

app.post('/addData', verifyToken, (req, res) => {


  
  data.forEach(user => {
    const sql = 'SELECT * FROM users WHERE username = ?';
    const values = [user.name];
    connection.query(sql, values, (error, results, fields) => {
      if (error) throw error;
      if (results.length > 0) {
        console.log(`User ${user.name} already exists`);
      } else {
        const sql = 'INSERT INTO users (username, password,type) VALUES (?, ?,?)';
        const values = [user.name, '123','user'];
        connection.query(sql, values, (error, results, fields) => {
          if (error) throw error;
          console.log('Data added successfully');
        });
      }
    });
  });

  const { Date, ClientID,Exchange ,ScriptName,intrus,cps,stocks,expirys,Strikes,qbf,rbf,valbf,BuyQty,BuyRate,BuyAmount,SaleQty,SaleRate,SaleAmount,NetQty,NetRate,NetAmount,ClosingPrice,Booked,Notional,Total} = req.body;
  const id = req.user.id;

  connection.query(
    `INSERT INTO user_data (admin_id, Date,ClientID,Exchange,ScriptName,intrus,cps,stocks,expirys,Strikes,qbf,rbf,valbf,BuyQty,BuyRate,BuyAmount,SaleQty,SaleRate,SaleAmount,NetQty,NetRate,NetAmount,ClosingPrice,Booked,Notional,Total) VALUES ('${id}','${Date}','${ClientID}','${Exchange}','${ScriptName}','${intrus}','${cps}','${stocks}','${expirys}','${Strikes}','${qbf}','${rbf}','${valbf}','${BuyQty}','${BuyRate}','${BuyAmount}','${SaleQty}','${SaleRate}','${SaleAmount}','${NetQty}','${NetRate}','${NetAmount}','${ClosingPrice}','${Booked}','${Notional}','${Total}')`,
    (error, results) => {
      if (error) {
        return res.status(500).json({ message: error.message });
      }

      res.json({ message: 'Data added successfully' });
    }
  );
});



app.get('/user/:val', verifyToken, (req, res) => {
  if (req.params.val == 'admin') {
    connection.query(
      `SELECT * FROM user_data WHERE admin_id = ${req.user.id}`,
      (error, results) => {
        if (error) {
          return res.status(500).json({ message: error.message });
        }
        res.send(results);
        newData.push(results);
      });
  } else {
    const query = `SELECT * FROM user_data WHERE ClientID = ?`;
    const values = [req.params.val];

    connection.query(
      query, values,
      (error, results) => {
        if (error) {
          return res.status(500).json({ message: error.message });
        }
        res.send(results);
          newData.push(results);

      });
  }
});

const workbook = XLSX.readFile('DeltaPosition_2023-02-07 (1).xlsx');
const firstSheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[firstSheetName];
const data = XLSX.utils.sheet_to_json(worksheet);


for (let i = 0; i < data.length; i++) {
  const item = data[i];
  const scriptName = item.ScriptName.split(" ")[0];

  if (scriptName == 'IO' || scriptName == 'EO') {
    const intru = item.ScriptName.split(" ")[0];
    const cp = item.ScriptName.split(" ")[1];
    const stock = item.ScriptName.split(" ")[2];
    const expiry = item.ScriptName.split(" ")[3];
    const Strike = item.ScriptName.split(" ")[4];

    const newItem = {
      Date: item.Date,
      ClientID: item.ClientID,
      Exchange: item.Exchange,
      ScriptName: stock,
      intrus: intru,
      cps: cp,
      stocks: stock,
      expirys: expiry,
      Strikes: Strike,
      'B.F. Qty': item['B.F. Qty'],
      'B.F. Rate': item['B.F. Rate'],
      'B.F. Value': item['B.F. Value'],
      BuyQty: item.BuyQty,
      BuyRate: item.BuyRate,
      BuyAmount: item.BuyAmount,
      SaleQty: item.SaleQty,
      SaleRate: item.SaleRate,
      SaleAmount: item.SaleAmount,
      NetQty: item.NetQty,
      NetRate: item.NetRate,
      NetAmount: item.NetAmount,
      ClosingPrice: item.ClosingPrice,
      Booked: item.Booked,
      Notional: item.Notional,
      Total: item.Total, 

    };
    newData.push(newItem);

  }
  else if (scriptName == 'IF' || scriptName == 'EF') {
    const intru = item.ScriptName.split(" ")[0];
    const stock = item.ScriptName.split(" ")[1];
    const expiry = item.ScriptName.split(" ")[2];


    const newItem = {
      Date: item.Date,
      ClientID: item.ClientID,
      Exchange: item.Exchange,

      ScriptName: stock,
      intrus: intru,
      expirys: expiry,
      'B.F. Qty': item['B.F. Qty'],
      'B.F. Rate': item['B.F. Rate'],
      'B.F. Value': item['B.F. Value'],
      BuyQty: item.BuyQty,
      BuyRate: item.BuyRate,
      BuyAmount: item.BuyAmount,
      SaleQty: item.SaleQty,
      SaleRate: item.SaleRate,
      SaleAmount: item.SaleAmount,
      NetQty: item.NetQty,
      NetRate: item.NetRate,
      NetAmount: item.NetAmount,
      ClosingPrice: item.ClosingPrice,
      Booked: item.Booked,
      Notional: item.Notional,
      Total: item.Total,

    };
    newData.push(newItem);
  } else if (scriptName == 'CGST' || scriptName == 'SGST' || scriptName == 'STAMP DUTY' || scriptName == 'CLEARING CHAGES' || scriptName == 'ROUNDING' || scriptName == 'SEBI FEES' || scriptName == 'TOC NSE Exchange' || scriptName == 'STT') {
    const newItem = {
      Date: item.Date,
      ClientID: item.ClientID,
      Exchange: item.Exchange,

      ScriptName: item.ScriptName,


      Total: item.Total,

    };
    expencs.push(newItem)
  }

  else {

  }
}


console.log(newData)


// const newData = data.map(item => {
//   const scriptName = item.ScriptName.split(" ");
//   const intru = scriptName[scriptName.length - 5];
//   const cp = scriptName[scriptName.length - 4];

//   const stock = scriptName[scriptName.length - 3];
//   const expiry = scriptName[scriptName.length - 2];
//   const Strike = scriptName[scriptName.length - 1];


//   return {
//     Date: item.Date,
//     ClientID: item.ClientID[0],
//     Exchange: item.Exchange,
//     // Symbol: symbol,
//     "B.F. Qty": item["B.F. Qty"],
//     "B.F. Rate": item["B.F. Rate"],
//     "B.F. Value": item["B.F. Value"],
//     BuyQty: item.BuyQty,
//     intru: intru,
//     cp: cp,
//     stock: stock,
//     expiry: expiry,
//     Strike: Strike,
//     BuyRate: item.BuyRate,
//     BuyAmount: item.BuyAmount,
//     SaleQty: item.SaleQty,
//     SaleRate: item.SaleRate,
//     SaleAmount: item.SaleAmount,
//     NetQty: item.NetQty,
//     NetRate: item.NetRate,
//     NetAmount: item.NetAmount,
//     ClosingPrice: item.ClosingPrice,
//     Booked: item.Booked,
//     Notional: item.Notional,
//     Total: item.Total
//   };
// });



function ExpencTotal() {
  const results = [];
  const scripts = new Map();

  for (const item of newData) {
    if (!scripts.has(item.ClientID)) {
      scripts.set(item.ClientID, { ClientID: item.ClientID, Total: 0 });
      results.push(scripts.get(item.ClientID));
    }
    scripts.get(item.ClientID).Total += item.Total;
  }

  return results;

}

function scriptvice() {

  const result = newData[0].reduce((acc, obj) => {
    if (!acc[obj.ScriptName]) {
      acc[obj.ScriptName] = 0;
    }
    acc[obj.ScriptName] += parseInt(obj.Total);
    return acc;
  }, {});
  return result;
}

app.get('/Expence/:id', (req, res) => {
  res.send(ExpencTotal());
});


app.get('/data', (req, res) => {
  res.send(newData);
});

app.get('/Total', (req, res) => {

  const data = newData;
  
  const total = data[0].reduce((acc, curr) => acc + parseInt(curr.Total), 0);

  res.send({ total });

});



app.get('/script', (req, res) => {

  res.send(scriptvice());
});


app.post("/transactions", (req, res) => {
  const data = req.body;
  console.log("Received data:", data);

  res.status(200).json({
    message: "Data received successfully"
  });
});


app.post('/d', (req, res) => {
  const datsa = req.body;

  console.log(req.body.data);
  // connection.query(`INSERT INTO data (admin_id, id, date, client_id, total)
  //   VALUES (?, ?, ?, ?, ?)`,
  //   [data.admin_id, data.id, data.Date, data.ClientID, data.Total],
  //   function (err) {
  //     if (err) {
  //       return console.error(err.message);
  //     }
  //     console.log(`Data added with rowid ${this.lastID}`);
  //     res.send({ message: 'Data added successfully' });
  //   });
});

app.listen(4500)
console.log('Server started on port 4500');


